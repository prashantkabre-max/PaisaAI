from data.nifty200 import SYMBOL_MAP

_last_vtt = {}


def parse_market_data(message):
    try:
        if not isinstance(message, dict):
            return None

        feeds = message.get("feeds", {})
        if not feeds:
            return None

        parsed = []

        for instrument_key, data in feeds.items():

            feed = data.get("fullFeed", {})
            market = feed.get("marketFF", {})
            ltpc = market.get("ltpc", {})
            ohlc = market.get("marketOHLC", {}).get("ohlc", [])

            candle = ohlc[0] if ohlc else {}

            current_vtt = int(market.get("vtt", 0))
            previous_vtt = _last_vtt.get(instrument_key, current_vtt)

            incremental_volume = max(0, current_vtt - previous_vtt)

            _last_vtt[instrument_key] = current_vtt

            ltp = ltpc.get("ltp")
            previous_close = candle.get("close")
            cp = ltpc.get("cp")
            print("DEBUG PARSER:", market)
            print("DEBUG PARSER:", market)

            # Replay mode sometimes sends cp as 0 or None.
            # Calculate it ourselves if required.
            if (cp is None or cp == 0) and previous_close not in (None, 0) and ltp is not None:
                cp = ((ltp - previous_close) / previous_close) * 100

            parsed.append({
                "symbol": SYMBOL_MAP.get(instrument_key, instrument_key),
                "ltp": ltp,
                "change_percent": cp,
                "open": candle.get("open"),
                "high": candle.get("high"),
                "low": candle.get("low"),
                "close": previous_close,
                "volume": incremental_volume,
            })

        if not parsed:
            return None

        return parsed[0]

    except Exception as e:
        print("Parser Error:", e)
        return None
