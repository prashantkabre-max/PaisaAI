    def on_message(self, message):

        market = self.process_market(message)

        if market is None:
            return

        self.process_completed_candle(market)

    def on_error(self, *args):
        print("ERROR:", args)
        traceback.print_exc()

    def on_close(self, *args):
        print("Connection Closed")

    def start(self):
        print("Connecting...")
        self.streamer.connect()
